package com.example.communications_t3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fabAddCont = (FloatingActionButton) findViewById(R.id.fabRequests);
        FloatingActionButton AddContact = (FloatingActionButton) findViewById(R.id.fabAddCont);
        //add listeners for the fabs - start with requests - needs to open a new activity
        fabAddCont.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this,Requests.class));
            }
        });
        //listener for the add contacts activity
        AddContact.setOnClickListener(new View.OnClickListener(){
            public void onClick(View z){
                startActivity(new Intent(MainActivity.this,AddContacts.class));
            }
        });

    }

}