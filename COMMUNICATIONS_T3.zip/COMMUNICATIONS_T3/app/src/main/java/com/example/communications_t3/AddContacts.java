package com.example.communications_t3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddContacts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contacts);
        //ok basically we need this shit to take in two user inputs, save em to Firebase and then report that the save was successful
    }
}