package com.example.communications_t3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Requests extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);
        //ok here we need to show some faux requests in the system and use the same "add contact" function here - just for the Demo and shit - low priority
    }
}